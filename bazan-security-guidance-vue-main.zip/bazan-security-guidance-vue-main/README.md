# How to Run locally

- In business application studio - go to Run Configurations and create a new configuration.
- Bind the configuration to destination with name: GWD_DEPLOY_HTML5
- Run the configuraion and wait until you see a notification with port number 6004
- Open the link and copy this link with the ui resource but without the html extension. So the url should look like the following: https://port6004-workspaces-ws-vq6n9.eu20.applicationstudio.cloud.sap/ui/ (please notice that for user the code vq6n9 will be different)
- Go to the file vite.config.mjs and replace the target with the URL you copied in previous step (later we will create env variables)
- Now open Terminal
- Navigate to the project folder and then navigate to the ui folder
- Run npm run dev, Wait until you'll see http://localhost:3000, click on it and then you'll see the vuetify app


# How to Deploy to ABAP

- Go to the project folder
- Go inside the ui folder
- Make sure that the file ui5-deploy.yaml contains the correct data (app name, package, transport etc.)
- If everything ok, run the command: npm run deploy
