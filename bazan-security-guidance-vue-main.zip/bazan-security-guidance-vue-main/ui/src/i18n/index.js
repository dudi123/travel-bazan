import { createI18n } from 'vue-i18n';

export const i18n = createI18n({
  locale: 'heb',
  globalInjection: true,
  legacy: false,
  messages: {
    heb: {
      title: 'הנחיות לנוסעים לחו"ל',
      pernrEmp: 'מספר עובד',
      empName: 'שם עובד',
      tripNumber: 'מספר נסיעה',
      tripDate: 'תאריך נסיעה',
      destination: 'יעד',
      readme:
        'בבקשה קראו את ההנחיות בלינק המצורף. סמנו שקראתם ומסכימים להנחיות. בסיום לחצו על שלח.',
      checkboxText: 'קראתי והנני מסכים/ה',
      send: 'שלח',
      instruction: 'קובץ הנחיות'
    },
    en: {
      title: 'Instructions for travelers abroad',
      pernrEmp: 'Employee Id',
      employeeName: 'Employee Name',
      tripNumber: 'TripNumber',
      tripDate: 'Trip Number',
      destination: 'Destination',
      readme:
        'בבקשה קראו את ההנחיות בלינק המצורף. סמנו שקראתם ומסכימים להנחיות. בסיום לחצו על שלח.',
      checkboxText: 'קראתי והנני מסכים/ה',
      send: 'שלח',
      instruction: 'קובץ הנחיות'
    }
  }
});
