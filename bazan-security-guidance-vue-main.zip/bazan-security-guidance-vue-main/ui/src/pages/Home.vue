<template>
  <v-container>
    <v-row class="header-row justify-center">
      <v-col cols="12" sm="6" md="2" class="d-flex align-center justify-center">
        <!-- Personal number -->
        <div class="personal-number">
          <div class="flex-row">
            <h2 class="text-title">{{ $t('pernrEmp') }}</h2>
            <font-awesome-icon :icon="['fas', 'id-card']" />
          </div>
          <div>
            <h3 class="text-lg font-bold">23344</h3>
          </div>
        </div>
      </v-col>
      <v-col cols="12" sm="6" md="2" class="d-flex align-center justify-center">
        <!-- Personal name -->
        <div class="personal-name">
          <div class="flex-row">
            <h2 class="text-title">{{ $t('empName') }}</h2>
            <font-awesome-icon :icon="['fas', 'user']" />
          </div>
          <div>
            <h3 class="text-lg font-bold">שלום כהן</h3>
          </div>
        </div>
      </v-col>
      <v-col cols="12" sm="6" md="2" class="d-flex align-center justify-center">
        <!-- Trip Number -->
        <div class="trip-number">
          <div class="flex-row">
            <h2 class="text-title">{{ $t('tripNumber') }}</h2>
            <font-awesome-icon :icon="['fas', 'hashtag']" />
          </div>
          <div>
            <h3 class="text-lg font-bold">1256987</h3>
          </div>
        </div>
      </v-col>
      <v-col cols="12" sm="6" md="2" class="d-flex align-center justify-center">
        <!-- Trip date -->
        <div class="trip-date">
          <div class="flex-row">
            <h2 class="text-title">{{ $t('tripDate') }}</h2>
            <font-awesome-icon :icon="['fas', 'calendar-days']" />
          </div>
          <div>
            <h3 class="text-lg font-bold">12/08/2025</h3>
          </div>
        </div>
      </v-col>
      <v-col cols="12" sm="6" md="2" class="d-flex align-center justify-center">
        <!-- Destination -->
        <div class="destination">
          <div class="flex-row">
            <h2 class="text-title">{{ $t('destination') }}</h2>
            <font-awesome-icon :icon="['fas', 'plane']" />
          </div>
          <div>
            <h3 class="text-lg font-bold">קנדה</h3>
          </div>
        </div>
      </v-col>
    </v-row>
    <v-row class="header-row justify-center">
      <!-- READ ME -->
      <div class="readme text-center mt-5 font-bold">
        <h4 class="text-lg">{{ $t('readme') }}</h4>
      </div>
    </v-row>

    <v-row class="header-row justify-center">
      <!-- FILE -->

      <div
        class="file-container text-center mt-5 flex gap-2 justify-center items-center"
      >
        <v-btn class="ma-2" color="primary" variant="outlined">
          {{ $t('instruction') }}
          <v-icon icon="mdi-alert-circle" end></v-icon>
        </v-btn>
      </div>
    </v-row>
    <v-row class="header-row justify-center">
      <!-- CHECKBOX -->
      <div class="checkbox-container flex flex-row-reverse justify-center mt-5">
        <input type="checkbox" v-model="checked" class="ml-2 w-3.5" />
        <label for="checkbox">{{ $t('checkboxText') }}</label>
      </div>
    </v-row>
    <v-row class="header-row justify-center">
      <!-- SEND BUTTON -->
      <div class="send-button-container flex justify-center mt-5">
        <v-btn class="ma-2" color="primary">
          {{ $t('send') }}
          <v-icon icon="mdi-checkbox-marked-circle" end></v-icon>
        </v-btn>
      </div>
    </v-row>
  </v-container>

  <v-dialog v-model="dialog" max-width="600px">
    <v-card>
      <!-- Card Content Section -->
      <v-card-text>
        <!-- Top Section: Image -->
        <v-img
          :src="errorImage"
          height="100"
          class="grey lighten-2"
          contain
        ></v-img>

        <!-- Bottom Section: Text -->
        <div class="mt-2 text-center">
          <p>User is not exist in GWD</p>
        </div>
      </v-card-text>

      <!-- Card Actions -->
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="primary" text @click="dialog = false">Close</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { getStartup, setUser } from '@/core/api';
import successImage from '@/assets/success.jpg';
import errorImage from '@/assets/error.png';

const startup = ref(null);
const odata = ref(null);
const error = ref(null);
const dialog = ref(false);

onMounted(async () => {
  try {
    const { data1 } = await getStartup();
    debugger;
    startup.value = data1;
    const sPath = '/ZhrTasGetDetailsSet';
    const filter = `$filter=Usid eq ${startup.value.id}`;

    try {
      const { aData } = await setUser(sPath, filter);
      odata.value = aData;
    } catch (err) {
      dialog = true;
      alert('err');
    }
  } catch (err) {
    const { status } = err.response;
    dialog.value = true;
    // alert('User is not exist in GWD');
  }
});
</script>

<style scoped>
/* Container styles */
.info-container {
  display: flex;
  flex-direction: row-reverse;
  align-items: center;
  gap: 1rem;
  margin-top: 2.5rem;
  justify-content: center;
}

/* Personal Number */
.personal-number,
.personal-name,
.trip-number,
.trip-date,
.destination {
  text-align: center; /* Centered text for mobile */
}

.flex-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem; /* Adjust gap */
}

/* Title styles */
.text-title {
  font-size: 1rem; /* Tailwind's text-base */
  font-family: 'Arimo', sans-serif; /* Use appropriate font-family */
  opacity: 0.6; /* Tailwind's opacity-60 */
  direction: rtl;
}

/* Modifying the font size and weight of h3 */
.text-lg {
  font-size: 1.125rem; /* Tailwind's text-lg */
  font-weight: 700; /* Tailwind's font-bold */
  direction: rtl;
}

/* README Section */
.readme {
  text-align: center;
}

/* File Section */
.file-container {
  margin-top: 1.25rem; /* Tailwind's mt-5 */
}

.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5); /* Tailwind's bg-gray-900 bg-opacity-50 */
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-container {
  position: relative;
  background: white;
  border-radius: 0.5rem; /* Tailwind's rounded-lg */
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Tailwind's shadow-lg */
  padding: 1.5rem; /* Tailwind's p-6 */
  width: 1028px;
  height: 700px;
}

.close-button {
  position: absolute;
  top: 0.25rem;
  left: 0.5rem;
  background-color: #3b82f6; /* Tailwind's bg-blue-500 */
  color: white; /* Text color */
  padding: 0.5rem 1rem; /* Padding for the button */
  border-radius: 0.375rem; /* Tailwind's rounded */
  cursor: pointer;
}

/* Checkbox Section */
.checkbox-container {
  margin-top: 5rem; /* Tailwind's mt-20 */
  display: flex;
}

/* Send Button */
.send-button-container {
  margin-top: 2.5rem; /* Tailwind's mt-10 */
  display: flex;
}

.send-button {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background-color: #3b82f6; /* Tailwind's bg-button */
  color: white; /* Text color */
  padding: 0.5rem 1rem; /* Tailwind's px-4 py-2 */
  border-radius: 9999px; /* Tailwind's rounded-full */
  transition: background-color 0.3s;
}

.send-button:hover {
  background-color: #2563eb; /* Tailwind's hover:bg-blue-600 */
}
.header-row {
  display: flex;
  flex-direction: row-reverse;
}
</style>
