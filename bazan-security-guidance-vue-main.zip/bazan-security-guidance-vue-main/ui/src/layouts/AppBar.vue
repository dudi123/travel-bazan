<template>
  <v-app-bar color="neutral50 appbar-header">
    <div class="appbar_container">
      <!-- <v-img :src="logo" :max-width="66" /> -->
      <div class="img_container">
        <img :src="logo" class="image-logo" />
      </div>
      <div class="title_container" style="column-gap: 24px">
        <h3>{{ $t('title') }}</h3>
      </div>
    </div>
  </v-app-bar>
</template>

<script setup>
import { useLocale } from 'vuetify';
import logo from '@/assets/bazan-logo.png';
import avatar from '@/assets/avatar.png';
import { ref } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { watch } from 'vue';

const { t } = useLocale();
const router = useRouter();
const route = useRoute();

const nav = ref('home');

const showNotifications = () => {};

//
</script>

<style lang="scss" scoped>
.image-logo {
  width: 3rem;
  height: 3rem;
  margin-left: 1rem;
}
.appbar-header {
  position: fixed !important;
}
.appbar_container {
  // d-flex justify-space-between align-center px-4
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-right: 4px;
  width: 100%;
}

.title_container {
  // d-flex align-center flex-grow-1 justify-center
  display: flex;
  justify-content: space-between;
  flex-grow: 1;
  justify-content: center;
}
</style>
