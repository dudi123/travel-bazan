import axios from 'axios';

const baseURL = 'GWD_DEPLOY_HTML5/sap/bc/ui2';
const baseURLODATA =
  'GWD_DEPLOY_HTML5/sap/opu/odata/sap/ZSECURITY_INSTRUCTIONS_SRV';

//// const baseURL = "GWD_DEPLOY_HTML5/sap/opu/odata/sap/ZSECURITY_INSTRUCTIONS_SRV";

const api = axios.create({
  baseURL
});
const apiOdata = axios.create({
  baseURLODATA
});
export default { api, apiOdata };
