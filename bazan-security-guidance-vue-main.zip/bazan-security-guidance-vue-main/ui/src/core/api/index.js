import client from './client';

// export const getTableData = async (params = { $top: 20, $skip: 0 }) => {
//   const { data } = await client.get("/ZhrTasGetDetailsSet", {
//     params,
//   });

//   return data.d?.results || data.d || data.value;
// };

export const getStartup = async () => {
  return client.api.get('start_up');
};

export const setUser = async (sPath, params) => {
  return client.apiOdata.get(`${sPath}?${params}`);
};
