/**
 * router/index.js
 *
 */

// Composables
// import { createRouter, createWebHashHistory } from 'vue-router';
// import HomePage from '@/pages/Home.vue';

// const routes = [
//   {
//     path: '/',
//     name: 'home',
//     component: HomePage,
//     props: false
//   }
// ];

// const router = createRouter({
//   history: createWebHashHistory(),
//   routes
// });

// export default router;
// Composables
import { createRouter, createWebHashHistory } from 'vue-router';

const routes = [
  {
    path: '/',
    component: () => import('@/layouts/Default.vue'),
    children: [
      {
        path: '',
        name: 'home',

        component: () =>
          import(/* webpackChunkName: "home" */ '@/pages/Home.vue')
      }
    ]
  }
];

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL), // you can use without hash as well by using the createWebHistory function
  routes
});

export default router;
